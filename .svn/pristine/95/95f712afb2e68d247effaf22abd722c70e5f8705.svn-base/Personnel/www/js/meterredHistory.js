summerready = function() {
	recordAll();
}
function recordAll() {
	$("#recordID").empty();
	var roomId = getQueryString("roomId");
	alert(roomId);
	summer.ajax({
		type : 'post',
		url : 'http://192.168.43.217:8080/cmcc/CopyFormController/record',
		param : {
			"roomId" : roomId//房屋id
		},
		header : {
			Authorization : "OAuth2: token",
			"Content-Type" : "application/json"
		}
	}, function(response) {
		response.data = JSON.parse(response.data);
		var code = response.data.code;
		var recordS = response.data.recordList;
		if (code == "200") {
		alert("xxxx");
			for (var i = 0; i < recordS.length; i++) {
				alert("www");
					var record = recordS[i];
					alert(record.receiptsName);
					var $li = $(
							'<li>'
							+'<div class="center-icon">'
							+'<img src="../img/inspect-icon.png"">'
							+'</div>'
							+'<div class="um-media-body">'
							+'<p class="notice-bt">'
							+'<span class="um-mobilebt32">'+record.readingDate+' </span>'
							+'<span class="um-mobilebt32">'+record.receiptsName+' </span>'
							+'</p>'
							+'<p class="um-gray f14 um-text-overflow2">暂无信息</p>'
							+'</div>'
							+'</li>'
						);
						$li.appendTo($("#recordID"));
			}
		}
	});
}

//获取路径中的值
function getQueryString(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var r = window.location.search.substr(1).match(reg);
	if (r != null)
		return unescape(r[2]);
	return null;
}