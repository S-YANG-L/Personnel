function submitAll(t) {
	var ids = getQueryString("ids");

	//保存数据
	summer.ajax({
		type : 'post',
		url : 'http://192.168.43.217:8080/cmcc/checkingin/disposebatchabnormal',
		param : {
			"staffName" : summer.getAppStorage("userName"),
			"staffId" : summer.getAppStorage("userId"),
			"tenantId" : summer.getAppStorage("tenantId"),
			"leaveGenre" : $("#leaveGenre").val(), //请假类型
			"start" : $("#start").val(), //开始时间
			"end" : $("#end").val(), //结束时间
			"cause" : $("#cause").val(), //请假原因
			"checkids" : ids//ids
		},
		header : {
			Authorization : "OAuth2: token",
			"Content-Type" : "application/json"
		}
	}, function(response) {
		response.data = JSON.parse(response.data);
		alert(response.data.state);
		//跳转页面
		summer.openWin({
			"id" : "attendanceADD",
			"url" : "/html/attendance_check.html"
		});
	}, function(response) {
		alert("请重新操作");
	});
}

//获取url参数
function getQueryString(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var r = window.location.search.substr(1).match(reg);
	if (r != null)
		return unescape(r[2]);
	return null;
}

//页面加载事件
summerready = function() {
	alert(summer.getAppStorage("userName"));
	$("#sponsor").val(summer.getAppStorage("userName"));
	//默认发起人
	$("#sponsor").attr("readonly", "readonly")
}