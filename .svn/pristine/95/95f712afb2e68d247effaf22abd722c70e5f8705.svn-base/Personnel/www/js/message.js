function check_notice() {
	summer.openWin({
	url : 'html/check_notice.html'
});

}

function standby_notice() {
	summer.openWin({
	id : 'standby_notice',
	url : 'html/standby_notice.html'
});
}

function notification() {
	summer.openWin({
	id : 'notification',
	url : 'html/notification.html'
});
}

summerready = function() {
	getInnumber();
}

//查询所有的巡检计划
function getInnumber(){
	summer.ajax({
		type : 'post',
		url : 'http://192.168.43.217:8080/cmcc/InspectionController/listInspection',
		param : {
			"staffName" : summer.getAppStorage("userName"),
			"staffId" : summer.getAppStorage("userId"),
			"tenantId" : summer.getAppStorage("tenantId")
		},
		header : {
			Authorization : "OAuth2: token",
			"Content-Type" : "application/json"
		}
	}, function(response) {
		response.data = JSON.parse(response.data);
		var code = response.data.code;
		var listInspection = response.data.listInspection;
		if(code == "200"){
			document.getElementById("Innumber").innerHTML = listInspection.length;
		}else{
			document.getElementById("Innumber").innerHTML ="0";
		}
		});
}