function getQueryString(name) { 
var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i"); 
var r = window.location.search.substr(1).match(reg); 
if (r != null) return unescape(r[2]); return null; 
}
summerready = function() {
	judgeGenre();
}

function judgeGenre(){
	var id = getQueryString("inspectionID");
	var inspection = getQueryString("num");
	var inspectionStartTime = getQueryString("inspectionStartTime");//开始时间
	var inspectionEndTime = getQueryString("inspectionEndTime");//结束时间
	var finishNumber = getQueryString("finishNumber");//频次
	if(inspection=="0"){//设备0
		device_management(id,inspectionStartTime,inspectionEndTime,finishNumber);
	}
	if(inspection=="2"){//装修1
		decoration_reg(id,inspectionStartTime,inspectionEndTime,finishNumber);
	}
	if(inspection=="1"){//空关巡检2
		house(id,inspectionStartTime,inspectionEndTime,finishNumber);
	}
	if(inspection=="3"){//园区楼宇巡检3
		inspection_mana(id,inspectionStartTime,inspectionEndTime,finishNumber)
	}
}

//设备
function device_management(id,inspectionStartTime,inspectionEndTime,finishNumber){
	$("#ListDiv").empty();
	var name= summer.getAppStorage("userName")
	summer.ajax({
		type : 'post',
		url : 'http://192.168.43.217:8080/cmcc/pollingDetails/devicemanagement',
		param : {
			"id" : id
		},
		header : {
			Authorization : "OAuth2: token",
			"Content-Type" : "application/json"
		}
	}, function(response) {
		response.data = JSON.parse(response.data);
		var code = response.data.code;
		var PrgDeviceManagementMiddleList = response.data.PrgDeviceManagementMiddleList;
		if(code=="200"){
			for (var i = 0; i < PrgDeviceManagementMiddleList.length; i++) {
				var PMM = PrgDeviceManagementMiddleList[i];
				var $div = $(
					'<div class="um-noticediv" style="margin-bottom:0.64rem;">'
						+'<div class="notice-head">'
							+'<div class="center-icon">'
								+'<img alt="" src="../img/work-repair-icon.png">'
							+'</div>'
							+'<div style="float:left;">'
								+'<h4 class="um-media-heading um-mobilebt32">'+PMM.deviceName+'</h4>'
								+'<p class="um-mobilebthui">'+inspectionStartTime+'</p>'
							+'</div>'
						+'</div>'
						+'<ul>'
							+'<li><span>巡检内容</span> <span>'+PMM.remarks+'</span> </li>'
							+'<li><span>巡检人</span> <span>'+name+'</span> </li>'
							+'<li><span>开始时间</span> <span>'+inspectionStartTime+'</span> </li>'
							+'<li><span>结束时间</span> <span>'+inspectionEndTime+'</span> </li>'
						+'</ul>'
					+'</div>'
					 );
				$div.appendTo($("#ListDiv"));
			}
		}else{
			alert(response.data.state);
		}
		});
}

//空关
function house(id,inspectionStartTime,inspectionEndTime,finishNumber){
	$("#ListDiv").empty();
	var name= summer.getAppStorage("userName")
	summer.ajax({
		type : 'post',
		url : 'http://192.168.43.217:8080/cmcc/pollingDetails/houseOff',
		param : {
			"id" : id
		},
		header : {
			Authorization : "OAuth2: token",
			"Content-Type" : "application/json"
		}
	}, function(response) {
		response.data = JSON.parse(response.data);
		var code = response.data.code;
		var PrgDeviceManagementMiddleList = response.data.PrgDeviceManagementMiddleList;
		if(code=="200"){
			for (var i = 0; i < PrgDeviceManagementMiddleList.length; i++) {
				var PMM = PrgDeviceManagementMiddleList[i];
				var $div = $(
					'<div class="um-noticediv" style="margin-bottom:0.64rem;">'
						+'<div class="notice-head">'
							+'<div class="center-icon">'
								+'<img alt="" src="../img/work-repair-icon.png">'
							+'</div>'
							+'<div style="float:left;">'
								+'<h4 class="um-media-heading um-mobilebt32">'+PMM.deviceName+'</h4>'
								+'<p class="um-mobilebthui">'+inspectionStartTime+'</p>'
							+'</div>'
						+'</div>'
						+'<ul>'
							+'<li><span>巡检内容</span> <span>'+PMM.remarks+'</span> </li>'
							+'<li><span>巡检人</span> <span>'+name+'</span> </li>'
							+'<li><span>开始时间</span> <span>'+inspectionStartTime+'</span> </li>'
							+'<li><span>结束时间</span> <span>'+inspectionEndTime+'</span> </li>'
						+'</ul>'
					+'</div>'
					 );
				$div.appendTo($("#ListDiv"));
			}
		}else{
			alert(response.data.state);
		}
		});
}
