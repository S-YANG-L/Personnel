//初始化执行
summerready = function() {
	selectOrder();
}

//获取url中的参数
function getQueryString(name) { 
var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i"); 
var r = window.location.search.substr(1).match(reg); 
if (r != null) return unescape(r[2]); return null; 
}

//查询工单详细信息
function selectOrder(){
	var id = getQueryString("id");
	$("#orderID").val(id);
	summer.ajax({
		type : 'post',
		url : 'http://192.168.43.217:8080/cmcc/order/selectOrder',
		param : {
			"id" : id
		},
		header : {
			Authorization : "OAuth2: token",
			"Content-Type" : "application/json"
		}
	}, function(response) {
		response.data = JSON.parse(response.data);
		var state = response.data.state;
		var orderBusinessDraft = response.data.orderBusinessDraft;
		if(state=="200"){
			document.getElementById("personInCharge").innerHTML= summer.getAppStorage("userName");//完成人
			if(orderBusinessDraft.orderContent != null){
				document.getElementById("theme").innerHTML= orderBusinessDraft.orderContent;
			}
			if(orderBusinessDraft.accomplishTime != null){
				document.getElementById("overTime").innerHTML= orderBusinessDraft.accomplishTime;
			}
			if(orderBusinessDraft.handlingSituation != null){
				document.getElementById("workFlow").innerHTML= orderBusinessDraft.handlingSituation;
			}
			if(orderBusinessDraft.billNumber != null){
				document.getElementById("serialNumber").innerHTML= orderBusinessDraft.billNumber;
			}
			if(orderBusinessDraft.repairContent != null){
				document.getElementById("content").innerHTML= orderBusinessDraft.repairContent;
			}
			if(orderBusinessDraft.repairPosition != null){
				document.getElementById("workSite").innerHTML= orderBusinessDraft.repairPosition;
			}
			if(orderBusinessDraft.userEvaluate != null){
				document.getElementById("userEvaluate").innerHTML=orderBusinessDraft.userEvaluate;
			}
			
			var userFraction= orderBusinessDraft.userFraction;//客户满意度
			//var oDiv=document.getElementById('rank');
				//var aLi=oDiv.getElementsByTagName('li');
				for(var i = 0; i < userFraction; i++){
					document.getElementById("li"+i).className='hover';
				}
				
				//$(this).nextAll().removeClass("hover");


		}else{
			alert(response.data.state);
		}
			});
}
