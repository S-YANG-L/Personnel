summerready = function() {
	getType();
}
//获取报事类型
function getType() {
	$("#typeSelect").empty();
	$("#name").val(summer.getAppStorage("userName"));
	$("#time").val(getTime());
	summer.ajax({
		type : 'post',
		url : 'http://192.168.43.217:8080/cmcc/reportGenre/type',
		param : {
			"tenantId" : summer.getAppStorage("tenantId")
		},
		header : {
			Authorization : "OAuth2: token",
			"Content-Type" : "application/json"
		}
	}, function(response) {
		response.data = JSON.parse(response.data);
		var code = response.data.code;
		var rGList = response.data.rGList;
		//alert(code);
		if (code == "200") {
			for (var i = 0; i < rGList.length; i++) {
				var report = rGList[i];
				var $option = $('<option value="' + report.id + '">' + report.reportGenre + '</option>');
				$option.appendTo($("#typeSelect"));
			}
		}
	});
}

//保存
function save(){
	summer.ajax({
		type : 'post',
		url : 'http://192.168.43.217:8080/cmcc/reportGenre/save',
		param : {
			"typeSelect":$("#typeSelect").val(),
			"name":$("#name").val(),
			"time":$("#time").val(),
			"site":$("#site").val(),
			"details":$("#details").val(),
			"tenantId" : summer.getAppStorage("tenantId")
		},
		header : {
			Authorization : "OAuth2: token",
			"Content-Type" : "application/json"
		}
	}, function(response) {
		response.data = JSON.parse(response.data);
		var code = response.data.code;
		if(code=="200"){
			alert("保存成功");
			summer.openWin({
	        //"url" : "index.html"
	    });
		}else{
			alert(response.data.message);
		}
		});
}


//获取当前时间  
function getTime(){
	var date = new Date();
	var year = date.getFullYear();

	var month = date.getMonth()+1;
	var day = date.getDate();
	var hour = date.getHours();
	var minute = date.getMinutes();
	var second = date.getSeconds();
	var nowTime = year+'-'+month+'-'+day+' '+hour+':'+minute+':'+second;
	return nowTime;
}