summerready = function(){
    // here is your code...
    
}﻿ 

function standby_notice_info(){
	summer.openWin({
        "id" : "standby_notice_info",
        "url" : "html/standby_notice_info.html"
    });
}