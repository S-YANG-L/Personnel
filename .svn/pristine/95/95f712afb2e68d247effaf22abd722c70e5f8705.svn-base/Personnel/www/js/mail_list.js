summerready = function() {
    async1();
}
var ViewModel = function() {
};
//Knockout绑定
var viewModel = new ViewModel();
function async1() {
    summer.ajax({
        "header" : {
            "Content-Type" : "application/json"
        },
        "type" : "POST",
        "url" : "http://192.168.43.217:8080/cmcc/contact/listClientP",
        "async" : false,
        "param" : {
            "tenantId" : 1
        },
    }, function(response) {//成功回调
        response.data = JSON.parse(response.data);
        var jsonArray2 = response.data.listClientP;
        summer.setStorage('jsonArray2', jsonArray2)
        viewModel.listClientP = ko.observableArray(summer.getStorage('jsonArray2'));
        ko.applyBindings(viewModel);
    }, function(response) {//失败回调
        alert(response.data);
        alert(response.error);
    });
    async2();
}

function async2() {
    summer.ajax({
        "header" : {
            "Content-Type" : "application/json"
        },
        "type" : "POST",
        "url" : "http://192.168.43.217:8080/cmcc/contact/listStaff",
        "param" : {
            tenantId : 1
        },
    }, function(response) {//成功回调
        response.data = JSON.parse(response.data);
        var jsonArray1 = response.data.listStaff;
        summer.setStorage('jsonArray1', jsonArray1)
        viewModel.listStaff = ko.observableArray(summer.getStorage('jsonArray1'));
        ko.applyBindings(viewModel);
    }, function(response) {//失败回调
        alert(response.data);
        alert(response.error);
    });
}
$(function() {
    var listview = UM.listview("#listview");
    //添加控件方法
    listview.on("itemClick", function(sender, args) {
        //这里可以处理行点击事件，参数sender即为当前列表实例对象，args对象有2个属性，即rowIndex(行索引)和$target(目标行的jquery对象)
        var item = viewModel.listStaff()[args.rowIndex];
        summer.setStorage('staffId', item.id)
        summer.openWin({
            id : 'mailDtl',
            url : '/html/mailDtl.html'
        });

    });
});
$(function() {
    var listview = UM.listview("#listview1");
    //添加控件方法
    listview.on("itemClick", function(sender, args) {
        //这里可以处理行点击事件，参数sender即为当前列表实例对象，args对象有2个属性，即rowIndex(行索引)和$target(目标行的jquery对象)
        var item = viewModel.listClientP()[args.rowIndex];
        summer.setStorage('custId', item.id)
        summer.openWin({
            id : 'custDtl',
            url : '/html/custDtl.html'
        });

    });
});
