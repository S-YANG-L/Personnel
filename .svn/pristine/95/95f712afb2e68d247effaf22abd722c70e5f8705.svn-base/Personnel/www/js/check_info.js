//获取传参
function getQueryString(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var r = window.location.search.substr(1).match(reg);
	if (r != null)
		return unescape(r[2]);
	return null;
}

//查询详情
function initiate() {
	var id = getQueryString("id");
	summer.ajax({
		type : 'post',
		url : 'http://192.168.43.217:8080/cmcc/InspectionController/singleInspection',
		param : {
			"id" : id
		},
		header : {
			Authorization : "OAuth2: token",
			"Content-Type" : "application/json"
		}
	}, function(response) {
		response.data = JSON.parse(response.data);
		var code = response.data.code;
		if (code == "200") {
			document.getElementById("inspection").innerHTML = response.data.inspection.inspection;
			document.getElementById("inspectionEndTime").innerHTML = response.data.inspection.inspectionEndTime;
			document.getElementById("remark").innerHTML = response.data.inspection.remark;
			document.getElementById("inspectionPerson").innerHTML = response.data.inspection.inspectionPerson;
			document.getElementById("inspectionStartTime").innerHTML = response.data.inspection.inspectionStartTime;
			document.getElementById("inEndTime").innerHTML = response.data.inspection.inspectionEndTime;
			$("#ID").val(response.data.inspection.id);
		} else {
			alert(response.data.message);
		}
	});
}

summerready = function() {
	initiate();
}