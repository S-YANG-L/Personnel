//获取参数
function getQueryString(name) { 
var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i"); 
var r = window.location.search.substr(1).match(reg); 
if (r != null) return unescape(r[2]); return null; 
}

//回显工单
function selectOrder(){
	var id = getQueryString("id");
	$("#orderID").val(id);
	summer.ajax({
		type : 'post',
		url : 'http://192.168.43.217:8080/cmcc/order/selectOrder',
		param : {
			"id" : id
		},
		header : {
			Authorization : "OAuth2: token",
			"Content-Type" : "application/json"
		}
	}, function(response) {
		response.data = JSON.parse(response.data);
		var state = response.data.state;
		var orderBusinessDraft = response.data.orderBusinessDraft;
		if(state=="200"){
			if(orderBusinessDraft.orderContent != null){
				document.getElementById("theme").innerHTML= orderBusinessDraft.orderContent;
			}
			if(orderBusinessDraft.billNumber != null){
				document.getElementById("serialNumber").innerHTML= orderBusinessDraft.billNumber;
			}
			if(orderBusinessDraft.repairContent != null){
				document.getElementById("content").innerHTML= orderBusinessDraft.repairContent;
			}
			if(orderBusinessDraft.repairPosition != null){
				document.getElementById("workSite").innerHTML= orderBusinessDraft.repairPosition;
			}
			if(orderBusinessDraft.sendPeople != null){
				document.getElementById("workerName").innerHTML= orderBusinessDraft.sendPeople;
			}
			if(orderBusinessDraft.appointmentDate != null){
				document.getElementById("totalTime").innerHTML= orderBusinessDraft.appointmentDate;
			}
		}else{
			alert(response.data.state);
		}
			});
}

//提交工作记录
function submitParticulars(){
	var id = $("#orderID").val();
	//var isAccomplish = $("#isAccomplish").val();
	var workFlow = $("#workFlow").val();
	summer.ajax({
		type : 'post',
		url : 'http://192.168.43.217:8080/cmcc/order/disposeachieve',
		param : {
			"id" : id,
			//"isAccomplish" : isAccomplish,
			"workFlow" : workFlow
		},
		header : {
			Authorization : "OAuth2: token",
			"Content-Type" : "application/json"
		}
	}, function(response) {
		response.data = JSON.parse(response.data);
		var state = response.data.state;
		if(state=="200"){
			alert("提交成功 请等待客户对您的评价");
			summer.openWin({
	        "url" : "html/work_order.html"
	    });
		}else{
			alert(response.data.state);
		}
		});
}


//初始化执行
summerready = function() {
	selectOrder();
}