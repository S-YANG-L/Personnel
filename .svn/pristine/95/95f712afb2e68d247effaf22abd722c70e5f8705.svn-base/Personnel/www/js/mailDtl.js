summerready = function() {
    dasources();
}
var ViewModel = function() {
};
//Knockout绑定
var viewModel = new ViewModel();
function dasources() {
    summer.ajax({
        "header" : {
            "Content-Type" : "application/json"
        },
        "type" : "POST",
        "url" : "http://192.168.43.217:8080/cmcc/contact/listStaff",
        "param" : {
            tenantId : 1,
            id : summer.getStorage('staffId')
        },
    }, function(response) {//成功回调
        response.data = JSON.parse(response.data);
        var jsonArray = response.data.listStaff;
        viewModel.data = ko.observableArray(jsonArray);
        ko.applyBindings(viewModel);
    }, function(response) {//失败回调
        alert(response.data);
        alert(response.error);
    });
}
