﻿function openTab(type,titles){
    var header = $summer.byId('header');
    var headerPos = $summer.offset(header);    
    var footer = $summer.byId('footer');
    var footerPos = $summer.offset(footer); 
	
    var width = $summer.winWidth();//==320
    var height = $summer.winHeight()-footerPos.h-headerPos.h;//gct:计算frame的高  
    $('#h-title').html(titles);    
	summer.openFrame({
		name: type,
		url: 'html/'+ type +'.html',
		rect: {
			x: 0,
			y: headerPos.h,
			w: width,
			h: height
		},
	});       
}
summerready=function(){
	openTab('main','智慧物业');
	summer.setAppStorage("userName","灰太狼");
	summer.setAppStorage("userId","1234567");
	summer.setAppStorage("tenantId","1");
	summer.setAppStorage("checkLocation","用友产业园");
	summer.setAppStorage("longitude","106.581515");//经度
	summer.setAppStorage("latitude","29.615467");//维度

}

 
