//保存外勤打卡信息
function outwork(t) {
	alert("111111111");
	summer.post("http://172.20.10.3:8080/cmcc/checkingin/itinerancy", {
		"officeHours" : $("#startTime").val(), //开始时间
		"closingTime" : $("#end").val(), //结束时间
		"name" : summer.getAppStorage("userName"), //发起人
		"location" : $("#location").val(), //地点
		"outworkCause" : $("#outworkCause").val(), //申请原因
		"userId" : summer.getAppStorage("userId"), //员工id
		"tenantId" : summer.getAppStorage("tenantId")//租户id
	}, {
		Authorization : "OAuth2:token"
	},function(response){
		alert("成功");
		//response.data = JSON.parse(response.data);
		//var restate=response.data.state;
		//alert(restate);
	},function(response){
		alert("错误");
	});

}