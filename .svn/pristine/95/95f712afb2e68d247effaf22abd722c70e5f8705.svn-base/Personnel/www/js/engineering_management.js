function chaobiao(){
	summer.openWin({
	        "id" : "chaobiao",
	        "url" : "html/chaobiao.html"
	    });
}

function chaobiao_info(){
	summer.openWin({
	        "id" : "chaobiao_info",
	        "url" : "html/chaobiao_info.html"
	    });
}
function goMeterReading(){
	var roomId = $("#roomList").val();
	summer.openWin({
	        "id" : "gometerreading",
	        "url" : "html/addMeterReading.html?roomId="+roomId
	    });

}

function inspection(){
	$("#pollingDIV").empty();
	summer.ajax({
		type : 'post',
		url : 'http://192.168.43.217:8080/cmcc/InspectionController/listInspection',
		param : {
			"staffName" : summer.getAppStorage("userName"),
			"staffId" : summer.getAppStorage("userId"),
			"tenantId" : summer.getAppStorage("tenantId")
		},
		header : {
			Authorization : "OAuth2: token",
			"Content-Type" : "application/json"
		}
	}, function(response) {
		response.data = JSON.parse(response.data);
		var code = response.data.code;
		var listInspection = response.data.listInspection;
		if(code == "200"){
		//拼接列表
			for (var i = 0; i < listInspection.length; i++) {
				var Inspection = listInspection[i];
				var $li = $(
					'<li class="um-listview-row" onclick="check_info(this,'+i+')">'
					+'<a href="#" class="um-list-centernotice">'
					+'<input type="hidden" id="inspectionID'+i+'"  value="'+Inspection.id+'"/>'
					+'<div class="center-icon">'
					+'<img src="../img/inspect-icon.png">'
					+'</div>'
					+'<div class="um-media-body">'
					+'<p class="notice-bt">'
					+'<span class="um-mobilebt32">'+Inspection.inspection+'</span>'
					+'<span class="um-gray f12 fr">'+Inspection.inspectionEndTime+'</span>'
					+'</p>'
					+'<p class="um-gray f14 um-text-overflow2">'+Inspection.remark+'</p>'
					+'<p class="um-gray f14 um-text-overflow2">巡检时间: '+Inspection.inspectionStartTime+'至'+Inspection.inspectionEndTime+'</p>'
					+'</div>'
					+'</a>'
					+'</li>'
					 );
				$li.appendTo($("#pollingDIV"));
			}
		}else{
			alert(response.data.message);
		}
		});

}

//跳向详情
function check_info(t , i){
	//var id = $("#abnormalState" + i).text();
	var id = $("#inspectionID" + i).val();
	summer.openWin({
	        "url" : "html/check_info.html?id="+id
	    });
}

//抄表
function imeterReading(){
	//添加抄表人
	document.getElementById("readingDetails").innerHTML = '抄表人: '+summer.getAppStorage("userName");
	$("#meterReadingID").empty();
	summer.ajax({
		type : 'post',
		url : 'http://192.168.43.217:8080/cmcc/CopyFormController/communityList',
		param : {
			"tenantId" : summer.getAppStorage("tenantId")
		},
		header : {
			Authorization : "OAuth2: token",
			"Content-Type" : "application/json"
		}
	}, function(response) {
		response.data = JSON.parse(response.data);
		var code = response.data.code;
		var communityList = response.data.communityList
		if(code=="200"){
			for (var i = 0; i < communityList.length; i++) {
				var community = communityList[i];
				var $li = $(
					'<li class="active"><a id="NameID'+i+'" onclick="particulars(this,'+i+')" >'+community.communityName+'</a><span></span></li>'
					+'<input type="hidden" id="communityID'+i+'" value="'+community.id+'"/>'
				);
				$li.appendTo($("#meterReadingID"));
			}
		}else{
			alert(response.data.massage);
		}
		});
}

//抄表详情
function particulars(t,i){
$("#villageList").empty();
	var id = $("#communityID" + i).val();
	summer.ajax({
		type : 'post',
		url : 'http://192.168.43.217:8080/cmcc/CopyFormController/villageList',
		param : {
			"id" : id
		},
		header : {
			Authorization : "OAuth2: token",
			"Content-Type" : "application/json"
		}
	}, function(response) {
		response.data = JSON.parse(response.data);
		var code = response.data.code;
		var villageList = response.data.villageList
		if(code == "200"){
			for (var i = 0; i < villageList.length; i++) {
				var village = villageList[i];
				if(village.villageId != null){
					var $option = $(
					'<option value="'+village.villageId+'">'+village.villageName+'</option>'
					);
					$option.appendTo($("#villageList"));
				}else{
					var $option = $(
					'<option>暂无小区信息</option>'
					);
					$option.appendTo($("#villageList"));
				}
			}
		}else{
			alert(response.data.massage);
		}
	});
}

//楼栋详情
function buildingChange(){
	$("#buildingList").empty();
	var id = $("#villageList").val();
	summer.ajax({
		type : 'post',
		url : 'http://192.168.43.217:8080/cmcc/CopyFormController/buildingList',
		param : {
			"id" : id
		},
		header : {
			Authorization : "OAuth2: token",
			"Content-Type" : "application/json"
		}
	}, function(response) {
		response.data = JSON.parse(response.data);
		var code = response.data.code;
		var buildingList = response.data.buildingList
		if(code == "200"){
			for (var i = 0; i < buildingList.length; i++) {
				var building = buildingList[i];
				if(building.buildingId != null){
					var $option = $(
					'<option value="'+building.buildingId+'">'+building.buildingName+'</option>'
				);
				$option.appendTo($("#buildingList"));
				}else{
					var $option = $(
					'<option >暂无楼栋信息</option>'
				);
				$option.appendTo($("#buildingList"));
				}
			}
		}else{
			alert(response.data.massage);
		}
	});
}
//房间详情
function roomHouseChange(){
	$("#roomList").empty();
	var id = $("#buildingList").val();
	summer.ajax({
		type : 'post',
		url : 'http://192.168.43.217:8080/cmcc/CopyFormController/roomList',
		param : {
			"id" : id
		},
		header : {
			Authorization : "OAuth2: token",
			"Content-Type" : "application/json"
		}
	}, function(response) {
		response.data = JSON.parse(response.data);
		var code = response.data.code;
		var roomList = response.data.roomList;
		if(code == "200"){
			for (var i = 0; i < roomList.length; i++) {
				var room = roomList[i];
				if(room.id != null){
					var $option = $(
					'<option value="'+room.id+'">'+room.houseName+'</option>'
				);
				$option.appendTo($("#roomList"));
				}else{
					var $option = $(
					'<option >暂无房间信息</option>'
				);
				$option.appendTo($("#roomList"));
				}
			}
		}else{
			alert(response.data.massage);
		}
	});	
}


summerready = function() {
	inspection();
	
}