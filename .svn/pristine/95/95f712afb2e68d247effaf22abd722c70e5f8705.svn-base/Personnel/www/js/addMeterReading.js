//获取路径中的值
function getQueryString(name) { 
var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i"); 
var r = window.location.search.substr(1).match(reg); 
if (r != null) return unescape(r[2]); return null; 
}

//提交抄表单
function submitAll(){
	var roomId = getQueryString("roomId");
	alert($("#meterGenre").text());
	summer.ajax({
		type : 'post',
		url : 'http://192.168.43.217:8080/cmcc/CopyFormController/submitAll',
		param : {
			"roomId" : roomId,//房屋id
			"tenantId" : summer.getAppStorage("tenantId"),//租户id
			"instrumentType" :$("#instrumentType").val(),//抄表单类型
			"meterGenre" :$("#meterGenre").text(),//仪表类型
			"meterGenreID" :$("#meterGenre").val(),//仪表类型id
			"initialReadingHistory" :$("#lastReading").val(),//本月度数
			"practical" :$("#practical").val(),//实际使用度数
			"isOpenAccount" :$("#isOpenAccount").val()//是否开张
		},
		header : {
			Authorization : "OAuth2: token",
			"Content-Type" : "application/json"
		}
	}, function(response) {
		response.data = JSON.parse(response.data);
		var code = response.data.code;
		alert(code);
		if(code=="200"){
			alert("保存成功");
		}else{
			alert(response.data.massage);
		}
		});
}

//计算实际使用的度数
function calculate(){
	var practical = parseFloat($("#lastReading").val())-parseFloat($("#initialReading").val())
	$("#practical").val(practical);
}


//回写仪表类型
function writeBackMeterGenre(){
	$("#meterGenre").empty();
	summer.ajax({
		type : 'post',
		url : 'http://192.168.43.217:8080/cmcc/CopyFormController/writeBackMeterGenre',
		param : {
		},
		header : {
			Authorization : "OAuth2: token",
			"Content-Type" : "application/json"
		}
	}, function(response) {
		response.data = JSON.parse(response.data);
		var code = response.data.code;
		var PrgInstrumentTypeList = response.data.PrgInstrumentTypeList;
		//alert(code);
			if(code=="200"){
				for (var i = 0; i < PrgInstrumentTypeList.length; i++) {
					var PrgInstrumentType = PrgInstrumentTypeList[i];
					var $option = $(
							'<option value="'+PrgInstrumentType.id+'">'+PrgInstrumentType.typeName+'</option>'
						);
						$option.appendTo($("#meterGenre"));
			}
		}else{
			alert(response.data.massage);
		}
		});
}

	//通过房屋id和仪表类型id查询上次刻度
function getParticulars(){
	var roomId = getQueryString("roomId");
	var meterGenre = $("#meterGenre").val();
	alert(roomId);
	//alert(meterGenre);
	summer.ajax({
		type : 'post',
		url : 'http://192.168.43.217:8080/cmcc/CopyFormController/getParticulars',
		param : {
			"roomId":roomId,
			"meterGenre":meterGenre
		},
		header : {
			Authorization : "OAuth2: token",
			"Content-Type" : "application/json"
		}
	}, function(response) {
		response.data = JSON.parse(response.data);
		var code = response.data.code;
		var initialReading = response.data.initialReading;
		var readingDate = response.data.readingDate;
		//alert(code);
		if(code == "200"){
			$("#initialReading").val(initialReading);
			$("#examineTime").val(readingDate);
		}else{
			alert(response.data.massage);
			$("#initialReading").val("0");
		}
		});
}

		
summerready = function() {
	//writeBack();
	writeBackMeterGenre();
}