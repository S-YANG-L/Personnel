﻿
function work_order_info(t ,i){
	//获取id
	var id = $("#orderID"+i).val();
	summer.openWin({
	        "url" : "html/work_order_info.html?id="+id
	    });
}

//跳向已完成工单详情页面
function result_feedback(t,i){
	//获取id
	var id = $("#recordID"+i).val();
	summer.openWin({
	        "url" : "html/result_feedback.html?id="+id
	    });
}

//已接单跳向工作记录
function work_record(t ,i){
	var id = $("#recordID"+i).val();
	summer.openWin({
        "url" : "html/work_record.html?id="+id
    });
}

//代办事项
function commission(){
	$("#orderCommission").empty();
	summer.ajax({
		type : 'post',
		url : 'http://192.168.43.217:8080/cmcc/order/getbacklog',
		param : {
			"singleId" : summer.getAppStorage("userId"),
			"tenantId" : summer.getAppStorage("tenantId")
		},
		header : {
			Authorization : "OAuth2: token",
			"Content-Type" : "application/json"
		}
	}, function(response) {
		response.data = JSON.parse(response.data);
		var state = response.data.state;
		var orderList = response.data.order;
			//alert(state);
		if(state=="200"){
			for (var i = 0; i < orderList.length; i++) {
					var order = orderList[i];
					var $li = $(
							'<li>'
							  +'<a href="#" class="btn" onclick="work_order_info(this,'+i+')">'
							  +'<input type="hidden" value="'+order.idString+'" id="orderID'+i+'" />'
							   +'<div class="center-icon">'
								 +'<img alt="" src="../img/bill-icon.png">'
							   +'</div>'
							   +'<div class="um-media-body">'
							     +'<h4 class="um-media-heading um-mobilebt32">'+order.orderContent+'</h4>'
							     +'<p class="um-mobilebthui">'+order.appointmentDate+'</p>'
							   +'</div>'
							  +'</a>'
							+'</li>'
						);
						$li.appendTo($("#orderCommission"));
			}
		}else{
			alert(state);
		}
			
		});
}

//已接单
function alreadyTakeOrders(){
	$("#takeOrdersUL").empty();
	summer.ajax({
		type : 'post',
		url : 'http://192.168.43.217:8080/cmcc/order/gettakeorders',
		param : {
			"singleId" : summer.getAppStorage("userId"),
			"tenantId" : summer.getAppStorage("tenantId")
		},
		header : {
			Authorization : "OAuth2: token",
			"Content-Type" : "application/json"
		}
	}, function(response) {
		response.data = JSON.parse(response.data);
		var state = response.data.state;
		var orderList = response.data.order;
			//alert(state);
		if(state=="200"){
			for (var i = 0; i < orderList.length; i++) {
					var order = orderList[i];
					var $li = $(
							'<li>'
							  +'<a href=" #" class="btn" onclick="work_record(this,'+i+')">'
							  +'<input type="hidden" value="'+order.idString+'" id="recordID'+i+'" />'
							    +'<div class="center-icon">'
							      +'<img alt="" src="../img/bill-icon.png">'
							    +'</div>'
							    +'<div class="um-media-body">'
							    	+'<h4 class="um-media-heading um-mobilebt32">'+order.orderContent+'</h4>'
							        +'<p class="um-mobilebthui">'+order.appointmentDate+'</p>'
							    +'</div>'
							  +'</a>'
							+'</li>'
						);
						$li.appendTo($("#takeOrdersUL"));
			}
		}else{
			alert(state);
		}
		});
}

//根据工单模糊查询
function obscure(){
	$("#seek").attr("style","display:none;");
	var orderContent =$("#obscureQuery").val();
	$("#orderCommission").empty();
	summer.ajax({
		type : 'post',
		url : 'http://192.168.43.217:8080/cmcc/order/obscure',
		param : {
			"singleId" : summer.getAppStorage("userId"),
			"tenantId" : summer.getAppStorage("tenantId"),
			"orderContent" : orderContent
		},
		header : {
			Authorization : "OAuth2: token",
			"Content-Type" : "application/json"
		}
	}, function(response) {
		response.data = JSON.parse(response.data);
		var state = response.data.state;
		var orderList = response.data.order;
			//alert(state);
		if(state=="200"){
			for (var i = 0; i < orderList.length; i++) {
					var order = orderList[i];
					var $li = $(
							'<li>'
							  +'<a href="#" class="btn" onclick="work_order_info(this,'+i+')">'
							  +'<input type="hidden" value="'+order.idString+'" id="orderID'+i+'" />'
							   +'<div class="center-icon">'
								 +'<img alt="" src="../img/bill-icon.png">'
							   +'</div>'
							   +'<div class="um-media-body">'
							     +'<h4 class="um-media-heading um-mobilebt32">'+order.orderContent+'</h4>'
							     +'<p class="um-mobilebthui">'+order.appointmentDate+'</p>'
							   +'</div>'
							  +'</a>'
							+'</li>'
						);
						$li.appendTo($("#orderCommission"));
			}
		}else{
			alert(state);
		}
		});
}

//获取已完成
function accomplish(){
	//alert("1111");
	$("#accomplishUL").empty();
	summer.ajax({
		type : 'post',
		url : 'http://192.168.43.217:8080/cmcc/order/getaccomplish',
		param : {
			"singleId" : summer.getAppStorage("userId"),
			"tenantId" : summer.getAppStorage("tenantId")
		},
		header : {
			Authorization : "OAuth2: token",
			"Content-Type" : "application/json"
		}
	}, function(response) {
		response.data = JSON.parse(response.data);
		var state = response.data.state;
		var orderList = response.data.order;
			//alert(state);
		if(state=="200"){
			for (var i = 0; i < orderList.length; i++) {
					var order = orderList[i];
					var $li = $(
							'<li>'
							  +'<a href="#" class="btn" onclick="result_feedback(this,+'+i+')">'
							  +'<input type="hidden" value="'+order.idString+'" id="recordID'+i+'" />'
							    +'<div class="center-icon">'
							      +'<img alt="" src="../img/bill-icon.png">'
							    +'</div>'
							    +'<div class="um-media-body">'
							    	+'<h4 class="um-media-heading um-mobilebt32">'+order.orderContent+'</h4>'
							        +'<p class="um-mobilebthui">'+order.appointmentDate+'</p>'
							    +'</div>'
							  +'</a>'
							+'</li>'
						);
						$li.appendTo($("#accomplishUL"));
			}
		}else{
			alert(state);
		}
		});
}

//显示搜索按钮
function showSeek(){
	$("#seek").attr("style","");
}

//初始化执行
summerready = function() {
	commission();
}