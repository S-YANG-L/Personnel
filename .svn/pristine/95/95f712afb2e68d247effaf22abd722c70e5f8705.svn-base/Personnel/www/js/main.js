//here is your code...
summerready = function () {
	openTab
	$summer.byId("content").innerHTML += "<h3 style='text-align: center'>Hello friends, welcome!</h3><h3 style='text-align: center'></h3>";
};
//签到
function attendance(){
	summer.openWin({
        "id" : "attendance",
        "url" : "html/attendance_check.html"
    });
}


//企业通讯录
function mail_list(){
	summer.openWin({
        "id" : "mail_list",
        "url" : "html/mail_list.html"
    });
}

//工单管理
function work_order(){
	summer.openWin({
	        "id" : "work_order",
	        "url" : "html/work_order.html"
	    });
}

//工程管理
function engineering_management(){
	summer.openWin({
	        "id" : "engineering_management",
	        "url" : "html/engineering_management.html"
	    });
}

//内部通知
function notification(){
	summer.openWin({
        "id" : "notification",
        "url" : "html/notification.html"
    });
}
//公共报事
function public_report(){
	summer.openWin({
        "id" : "public_report",
        "url" : "html/public_report.html"
    });

}
//图片轮播
summerready = function () {
	$(function() {
		var list = [
			{
				content: "../img/g1.jpg"
			}, 
			{
				content: "../img/g2.jpg"
			},
			 {
				content: "../img/g3.jpg"
			}
		];
		var islider = new iSlider({
			type: 'pic',
			data: list,
			dom: document.getElementById("iSlider-wrapper"),
			isLooping: true,
			animateType: 'default',
			onslideend: function(idx) {
				$("#nav").find("li").eq(idx).addClass("active").siblings("li").removeClass("active");
			},
		});
		islider.addBtn();
		$("#nav").find("li").on("click", function() {
			$(this).addClass("active").siblings("li").removeClass("active");
			var i = $(this).index();
			islider.slideTo(i);
		});	
		$(islider.wrap).on("click",".islider-btn-outer",function(){
			var i = islider.slideIndex;
			$("#nav").find("li").eq(i).addClass("active").siblings("li").removeClass("active");
		});	
	});
}