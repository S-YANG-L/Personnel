function conditionSUB(t) {
	var id = getQueryString("id");
	var inspection = getQueryString("inspection");
	summer.ajax({
		type : 'post',
		url : 'http://192.168.43.217:8080/cmcc/InspectionController/save',
		param : {
			"name" : summer.getAppStorage("userName"),
			"time" : $("#time").val(),
			"normal" : $("#normal").val(),  
			"remark" : $("#remark").val(),
			"tenantId" : summer.getAppStorage("tenantId"),
			"id" : id,
			"inspection" : inspection
		},
		header : {
			Authorization : "OAuth2: token",
			"Content-Type" : "application/json"
		}
	}, function(response) {
		response.data = JSON.parse(response.data);
		var code = response.data.code;
		if(code == "200"){
			alert("保存成功");
			summer.openWin({
		        "url" : "html/check_info.html?id="+id
   				 });
		}else{
			alert(response.data.message)
		}
	});
}

//获取传参
function getQueryString(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var r = window.location.search.substr(1).match(reg);
	if (r != null)
		return unescape(r[2]);
	return null;
}

function fanhui(){
	var id = getQueryString("id");
	summer.openWin({
		        "url" : "html/check_info.html?id="+id
   				 });
}

summerready = function() {
	$("#name").val(summer.getAppStorage("userName"));
	$("#name").attr("readonly", "readonly");
}